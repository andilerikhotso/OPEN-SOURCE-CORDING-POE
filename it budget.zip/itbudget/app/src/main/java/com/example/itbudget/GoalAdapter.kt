package com.example.itbudget


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GoalAdapter(private val goalList: List<Goal>) : RecyclerView.Adapter<GoalAdapter.GoalViewHolder>() {

    class GoalViewHolder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val month: TextView = itemView.findViewById(R.id.goalMonth)
        val minGoal: TextView = itemView.findViewById(R.id.goalMin)
        val maxGoal: TextView = itemView.findViewById(R.id.goalMax)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.goal_item, parent, false)
        return GoalViewHolder(view)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        val goal = goalList[position]
        holder.month.text = "Month: ${goal.month}"
        holder.minGoal.text = "Min Goal: R${goal.minGoal}"
        holder.maxGoal.text = "Max Goal: R${goal.maxGoal}"
    }

    override fun getItemCount(): Int = goalList.size
}
