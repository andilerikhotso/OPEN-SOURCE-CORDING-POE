package com.example.itbudget

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ViewExpensesActivity : AppCompatActivity() {

    private lateinit var expenseRecyclerView: RecyclerView
    private lateinit var expenseAdapter: ExpenseAdapter
    private lateinit var dbHelper: DBHelper
    private var expenseList = mutableListOf<Expense>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_expenses)

        expenseRecyclerView = findViewById(R.id.expensesRecyclerView)
        dbHelper = DBHelper(this)

        // Set up RecyclerView
        expenseAdapter = ExpenseAdapter(expenseList)
        expenseRecyclerView.layoutManager = LinearLayoutManager(this)
        expenseRecyclerView.adapter = expenseAdapter

        // Load expenses from the database
        loadExpenses()

    }

    private fun loadExpenses() {
        // Clear the existing list before loading data
        expenseList.clear()

        // Fetch all expenses from the database
        val expenses = dbHelper.getExpensesForUser(userId = 1) // Assuming userId = 1 for now
        if (expenses.isNotEmpty()) {
            expenseList.addAll(expenses)
            expenseAdapter.notifyDataSetChanged()
        } else {
            Toast.makeText(this, "No expenses found", Toast.LENGTH_SHORT).show()
        }
    }
}
