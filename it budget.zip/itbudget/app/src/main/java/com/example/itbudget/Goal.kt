package com.example.itbudget

data class Goal(
    val goalId: Int,
    val userId: Int,
    val month: String,
    val minGoal: Double,
    val maxGoal: Double
)
