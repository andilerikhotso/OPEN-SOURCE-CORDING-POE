package com.example.itbudget

data class BudgetGoal(
    val month: String,
    val minGoal: Double,
    val maxGoal: Double
)
