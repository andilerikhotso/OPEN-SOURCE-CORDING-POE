package com.example.itbudget

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import android.util.Log // Import for logging

class MainActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var addExpenseCard: LinearLayout
    private lateinit var addCategoryCard: LinearLayout
    private lateinit var addGoalCard: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Ensure this matches your layout file name

        sharedPreferences = getSharedPreferences("user_session", Context.MODE_PRIVATE)


        // Alternative way to check if the user is logged in
        if (!isUserLoggedIn()) {
            Log.d("MainActivity", "User not logged in, redirecting to LoginActivity")
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        Log.d("MainActivity", "User is logged in, proceeding to main activity")

        // Initialize and set up click listeners for the cards
        addExpenseCard = findViewById(R.id.addExpense)
        addExpenseCard.setOnClickListener {
            navigateToAddExpense()
        }

        addCategoryCard = findViewById(R.id.addCategory)
        addCategoryCard.setOnClickListener {
            navigateToAddCategory()
        }
        addGoalCard = findViewById(R.id.addGoal)
        addGoalCard.setOnClickListener {
            navigateToAddGoal()
        }


    }

    private fun navigateToAddExpense() {
        val intent = Intent(this, AddExpenseActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToAddCategory() {
        val intent = Intent(this, AddCategoryActivity::class.java)
        startActivity(intent)
    }
    private fun navigateToAddGoal() {
        val intent = Intent(this, GoalActivity::class.java)
        startActivity(intent)
    }

    //  moved the isLoggedIn check to its own function for better readability
    private fun isUserLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }
}
