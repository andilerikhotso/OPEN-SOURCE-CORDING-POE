package com.example.itbudget

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.*

class AddExpenseActivity : AppCompatActivity() {

    private lateinit var expenseAmountEditText: EditText
    private lateinit var expenseDescriptionEditText: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var expenseDateEditText: EditText
    private lateinit var startTimeEditText: EditText
    private lateinit var endTimeEditText: EditText
    private lateinit var attachPhotoBtn: Button
    private lateinit var saveExpenseBtn: Button

    private val CAMERA_REQUEST_CODE = 100
    private var photoUri: String? = null // Store the photo URI if taken
   private lateinit var viewExpenseBtn: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        expenseAmountEditText = findViewById(R.id.expenseAmount)
        expenseDescriptionEditText = findViewById(R.id.expenseDescription)
        categorySpinner = findViewById(R.id.categorySpinner)
        expenseDateEditText = findViewById(R.id.expenseDate)
        startTimeEditText = findViewById(R.id.startTime)
        endTimeEditText = findViewById(R.id.endTime)
        attachPhotoBtn = findViewById(R.id.attachPhotoBtn)
        saveExpenseBtn = findViewById(R.id.saveExpenseBtn)
        viewExpenseBtn = findViewById(R.id.viewAllExpenses)
        val categories = arrayOf("Food", "Transport", "Entertainment", "Health", "Others") // example categories
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = spinnerAdapter
        viewExpenseBtn.setOnClickListener {
            val intent = Intent(this, ViewExpensesActivity::class.java)
            startActivity(intent)
        }
        expenseDateEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                this,
                { _, selectedYear, selectedMonth, selectedDay ->
                    val formattedDate = "${selectedDay}/${selectedMonth + 1}/$selectedYear"
                    expenseDateEditText.setText(formattedDate)
                },
                year,
                month,
                dayOfMonth
            )
            datePickerDialog.show()
        }

        startTimeEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timePickerDialog = TimePickerDialog(
                this,
                { _, selectedHour, selectedMinute ->
                    val formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                    startTimeEditText.setText(formattedTime)
                },
                hour,
                minute,
                true
            )
            timePickerDialog.show()
        }

        endTimeEditText.setOnClickListener {
            val calendar = Calendar.getInstance()
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val timePickerDialog = TimePickerDialog(
                this,
                { _, selectedHour, selectedMinute ->
                    val formattedTime = String.format("%02d:%02d", selectedHour, selectedMinute)
                    endTimeEditText.setText(formattedTime)
                },
                hour,
                minute,
                true
            )
            timePickerDialog.show()
        }

        // Open the camera to attach a photo
        attachPhotoBtn.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    android.Manifest.permission.CAMERA
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.CAMERA),
                    CAMERA_REQUEST_CODE
                )
            } else {
                openCamera()
            }
        }

        // Save the expense data to the database
        saveExpenseBtn.setOnClickListener {
            val amountStr = expenseAmountEditText.text.toString().trim()
            val description = expenseDescriptionEditText.text.toString().trim()
            val categoryId = categorySpinner.selectedItemPosition + 1 // Assuming IDs match position + 1
            val date = expenseDateEditText.text.toString().trim()
            val startTime = startTimeEditText.text.toString().trim()
            val endTime = endTimeEditText.text.toString().trim()

            if (amountStr.isEmpty() || description.isEmpty() || date.isEmpty() || startTime.isEmpty() || endTime.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                val amount = amountStr.toDoubleOrNull()
                if (amount == null) {
                    Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val expense = Expense(
                    userId = 1, // hardcoded for now
                    categoryId = categoryId,
                    amount = amount,
                    description = description,
                    date = date,
                    startTime = startTime,
                    endTime = endTime,
                    photoPath =  photoUri
                )

                val dbHelper = DBHelper(this)
                val result = dbHelper.addExpense(expense)

                if (result > 0) {
                    Toast.makeText(this, "Expense saved successfully", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Failed to save expense", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Open the camera to capture a photo
    private fun openCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)
    }

    // Handle the result of the camera capture
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CAMERA_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val photo = data?.extras?.get("data") as? Bitmap
            // Save the image URI to store it
            photoUri = saveImageToStorage(photo)
            Toast.makeText(this, "Photo attached successfully", Toast.LENGTH_SHORT).show()
        }
    }

    // Save the image to local storage and return the URI (this could be improved with actual file storage)
    private fun saveImageToStorage(bitmap: Bitmap?): String? {
        if (bitmap != null) {
            val imageFile = File(filesDir, "expense_${UUID.randomUUID()}.jpg")
            val fileOutputStream = FileOutputStream(imageFile)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fileOutputStream)
            fileOutputStream.close()
            return imageFile.absolutePath
        }
        return null
    }
}