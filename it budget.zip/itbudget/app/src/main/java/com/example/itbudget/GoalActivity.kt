package com.example.itbudget

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class GoalActivity : AppCompatActivity() {

    private lateinit var monthInput: EditText
    private lateinit var minGoalInput: EditText
    private lateinit var maxGoalInput: EditText
    private lateinit var saveGoalsBtn: Button
    private lateinit var dbHelper: DBHelper
    private lateinit var goalRecycler: RecyclerView
    private val goalList = mutableListOf<Goal>()
    private lateinit var goalAdapter: GoalAdapter
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goal)

        // Retrieve the actual logged-in user ID
        val sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE)
        userId = sharedPreferences.getInt("userId", -1)

        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Initialize UI elements
        monthInput = findViewById(R.id.monthInput)
        minGoalInput = findViewById(R.id.minGoalInput)
        maxGoalInput = findViewById(R.id.maxGoalInput)
        saveGoalsBtn = findViewById(R.id.saveGoalsBtn)

        goalRecycler = findViewById(R.id.goalRecycler)
        goalRecycler.layoutManager = LinearLayoutManager(this)
        goalAdapter = GoalAdapter(goalList)
        goalRecycler.adapter = goalAdapter

        dbHelper = DBHelper(this)

        loadGoals()

        // Save button click listener
        saveGoalsBtn.setOnClickListener {
            val month = monthInput.text.toString().trim()
            val minGoal = minGoalInput.text.toString().trim()
            val maxGoal = maxGoalInput.text.toString().trim()

            // Validate input
            if (month.isEmpty() || minGoal.isEmpty() || maxGoal.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            try {
                // Save goal to the database
                val success = dbHelper.setMonthlyBudgetGoal(
                    userId = userId,
                    month = month,
                    min = minGoal.toDouble(),
                    max = maxGoal.toDouble()
                )

                // Show feedback based on success
                if (success) {
                    Toast.makeText(this, "Budget goals saved", Toast.LENGTH_SHORT).show()
                    loadGoals() // Refresh the list after saving
                } else {
                    Toast.makeText(this, "Failed to save goals", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                // Catch potential exceptions (like invalid input conversion)
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Load goals from the database
    private fun loadGoals() {
        try {
            goalList.clear()
            goalList.addAll(dbHelper.getAllGoals(userId)) // Ensure userId is valid
            goalAdapter.notifyDataSetChanged()
        } catch (e: Exception) {
            Toast.makeText(this, "Error loading goals: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
