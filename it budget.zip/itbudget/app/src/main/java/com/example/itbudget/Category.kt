package com.example.itbudget

import androidx.room.Entity
import androidx.room.PrimaryKey

data class Category(
    val categoryId: Int=0,
    val userId: Int,
    val categoryName: String,
    val type: String // "Expense" or "Income"
)
