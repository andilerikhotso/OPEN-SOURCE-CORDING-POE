package com.example.itbudget

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ExpenseAdapter(private val expenseList: List<Expense>) :
    RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_expense, parent, false)
        return ExpenseViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        val expense = expenseList[position]
        holder.amountTextView.text = "Amount: ${expense.amount}"
        holder.descriptionTextView.text = "Description: ${expense.description}"
        holder.dateTextView.text = "Date: ${expense.date}"
        holder.categoryTextView.text = "Category: ${expense.categoryId}"

        // Load image if available
        if (expense.photoPath != null && expense.photoPath.isNotEmpty()) {
            Glide.with(holder.itemView.context)
                .load(Uri.parse(expense.photoPath)) // Load image from file path
                .into(holder.expenseImageView)
        } else {
            holder.expenseImageView.setImageResource(R.drawable.logo) // Set a default image if no image exists
        }
    }

    override fun getItemCount(): Int = expenseList.size

    inner class ExpenseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val amountTextView: TextView = itemView.findViewById(R.id.amountTextView)
        val descriptionTextView: TextView = itemView.findViewById(R.id.descriptionTextView)
        val dateTextView: TextView = itemView.findViewById(R.id.dateTextView)
        val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
        val expenseImageView: ImageView = itemView.findViewById(R.id.expenseImageView) // ImageView for displaying the photo
    }
}
