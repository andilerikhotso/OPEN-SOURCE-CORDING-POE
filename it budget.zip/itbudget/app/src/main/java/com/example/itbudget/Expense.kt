package com.example.itbudget

import androidx.room.Entity
import androidx.room.PrimaryKey

data class Expense(
    val expenseId: Int = 0,              // <- Default value added
    val userId: Int,
    val categoryId: Int,
    val amount: Double,
    val description: String,
    val date: String,
    val startTime: String,
    val endTime: String,
    val photoPath: String?
)