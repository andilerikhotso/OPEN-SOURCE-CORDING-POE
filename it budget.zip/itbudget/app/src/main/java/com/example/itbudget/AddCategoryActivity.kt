package com.example.itbudget

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AddCategoryActivity : AppCompatActivity() {

    private lateinit var newCategoryInput: EditText
    private lateinit var incomeOrExpenseSpinner: Spinner
    private lateinit var addCategoryBtn: Button
    private lateinit var categoryRecycler: RecyclerView
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var dbHelper: DBHelper
    private val categoryList = mutableListOf<Category>()
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_category)

        // Get the logged-in user ID from SharedPreferences
        val sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE)
        userId = sharedPreferences.getInt("userId", -1) // Match exactly how it was saved
        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        // Initialize views
        newCategoryInput = findViewById(R.id.newCategoryInput)
        incomeOrExpenseSpinner = findViewById(R.id.income_or_expense)
        addCategoryBtn = findViewById(R.id.addCategoryBtn)
        categoryRecycler = findViewById(R.id.categoryRecycler)
        dbHelper = DBHelper(this)

        // Setup spinner
        val options = arrayOf("Expense", "Income")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, options)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        incomeOrExpenseSpinner.adapter = spinnerAdapter

        // Setup RecyclerView
        categoryAdapter = CategoryAdapter(categoryList)
        categoryRecycler.layoutManager = LinearLayoutManager(this)
        categoryRecycler.adapter = categoryAdapter

        // Load categories
        loadCategories()

        // Add category
        addCategoryBtn.setOnClickListener {
            val categoryName = newCategoryInput.text.toString().trim()
            val type = incomeOrExpenseSpinner.selectedItem.toString()

            if (categoryName.isEmpty()) {
                Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newCategory = Category(
                userId = userId,
                categoryName = categoryName,
                type = type
            )

            val success = dbHelper.insertCategory(newCategory,userId)
            if (success) {
                Toast.makeText(this, "Category added", Toast.LENGTH_SHORT).show()
                newCategoryInput.text.clear()
                loadCategories()
            } else {
                Toast.makeText(this, "Failed to add category", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun loadCategories() {
        categoryList.clear()
        categoryList.addAll(dbHelper.getAllCategories(userId))
        categoryAdapter.notifyDataSetChanged()
    }
}
