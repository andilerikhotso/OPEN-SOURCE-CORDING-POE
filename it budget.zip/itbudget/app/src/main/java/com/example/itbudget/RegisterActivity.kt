package com.example.itbudget

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register) // Your XML file

        dbHelper = DBHelper(this)

        val usernameInput = findViewById<EditText>(R.id.surnameInput)
        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val alreadyRegistered = findViewById<TextView>(R.id.alreadyRegistered)

        registerButton.setOnClickListener {
            val username = usernameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()

            // Basic validation
            if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if the user already exists
            if (dbHelper.checkUserExists(email)) {
                Toast.makeText(this, "User already registered", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Create a new user object
            val user = User(username = username, email = email, password = password)

            // Insert the user into the local database
            val isInserted = dbHelper.insertUser(user)

            if (isInserted) {
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java)) // Redirect to login screen
                finish()
            } else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
            }
        }

        alreadyRegistered.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java)) // Go to login if already registered
        }
    }
}
