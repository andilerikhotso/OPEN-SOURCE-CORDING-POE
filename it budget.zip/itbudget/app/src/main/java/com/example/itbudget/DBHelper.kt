package com.example.itbudget

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, "UserDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        db.execSQL("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            email TEXT,
            password TEXT
        );
    """.trimIndent())

        // Create categories table
        db.execSQL("""
        CREATE TABLE categories (
            category_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category_name TEXT NOT NULL,
            type TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    """.trimIndent())

        // Create expenses table
        db.execSQL("""
        CREATE TABLE expenses (
            expense_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            description TEXT,
            date TEXT NOT NULL,
            start_time TEXT,
            end_time TEXT,
            photo_path TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (category_id) REFERENCES categories(category_id)
        );
    """.trimIndent())

        // Create budget_goals table
        db.execSQL("""
        CREATE TABLE budget_goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            month TEXT,
            min_goal REAL,
            max_goal REAL,
            FOREIGN KEY (user_id) REFERENCES users(id)
    );
    """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS expenses")
        db.execSQL("DROP TABLE IF EXISTS categories")
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    fun insertUser(user: User): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("username", user.username)
            put("email", user.email)
            put("password", user.password)
        }
        val result = db.insert("users", null, values)
        return result != -1L
    }

    fun checkUserExists(email: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE email = ?", arrayOf(email))
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", arrayOf(username, password))
        val isValid = cursor.count > 0
        cursor.close()
        return isValid
    }
    fun getUserIdByUsernameAndPassword(username: String, password: String): Int {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT id FROM users WHERE username = ? AND password = ?",
            arrayOf(username, password)
        )

        val userId = if (cursor.moveToFirst()) {
            cursor.getInt(cursor.getColumnIndexOrThrow("id"))
        } else {
            -1
        }
        cursor.close()
        return userId
    }


    fun insertCategory(category: Category,userId: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", userId)
            put("category_name", category.categoryName)
            put("type", category.type)
        }
        val result = db.insert("categories", null, values)
        return result != -1L
    }


    fun addExpense(expense: Expense): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", expense.userId)
            put("category_id", expense.categoryId)
            put("amount", expense.amount)
            put("description", expense.description)
            put("date", expense.date)
            put("start_time", expense.startTime)
            put("end_time", expense.endTime)
            put("photo_path", expense.photoPath)
        }
        return db.insert("expenses", null, values)
    }
    fun getExpensesForUser(userId: Int): List<Expense> {
        val expenses = mutableListOf<Expense>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM expenses WHERE user_id = ?", arrayOf(userId.toString()))

        if (cursor.moveToFirst()) {
            do {
                val expense = Expense(
                    expenseId = cursor.getInt(cursor.getColumnIndexOrThrow("expense_id")),
                    userId = cursor.getInt(cursor.getColumnIndexOrThrow("user_id")),
                    categoryId = cursor.getInt(cursor.getColumnIndexOrThrow("category_id")),
                    amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    startTime = cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    endTime = cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    photoPath = cursor.getString(cursor.getColumnIndexOrThrow("photo_path"))
                )
                expenses.add(expense)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return expenses
    }
    fun getExpensesByCategory(userId: Int, categoryId: Int): List<Expense> {
        val expenses = mutableListOf<Expense>()
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM expenses WHERE user_id = ? AND category_id = ?",
            arrayOf(userId.toString(), categoryId.toString())
        )

        if (cursor.moveToFirst()) {
            do {
                val expense = Expense(
                    expenseId = cursor.getInt(cursor.getColumnIndexOrThrow("expense_id")),
                    userId = cursor.getInt(cursor.getColumnIndexOrThrow("user_id")),
                    categoryId = cursor.getInt(cursor.getColumnIndexOrThrow("category_id")),
                    amount = cursor.getDouble(cursor.getColumnIndexOrThrow("amount")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date")),
                    startTime = cursor.getString(cursor.getColumnIndexOrThrow("start_time")),
                    endTime = cursor.getString(cursor.getColumnIndexOrThrow("end_time")),
                    photoPath = cursor.getString(cursor.getColumnIndexOrThrow("photo_path"))
                )
                expenses.add(expense)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return expenses
    }
    fun getAllGoals(userId: Int): List<Goal> {
        val goals = mutableListOf<Goal>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM budget_goals WHERE user_id = ?", arrayOf(userId.toString()))
        if (cursor.moveToFirst()) {
            do {
                val goal = Goal(
                    goalId = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    userId = cursor.getInt(cursor.getColumnIndexOrThrow("user_id")),
                    month = cursor.getString(cursor.getColumnIndexOrThrow("month")),
                    minGoal = cursor.getDouble(cursor.getColumnIndexOrThrow("min_goal")),
                    maxGoal = cursor.getDouble(cursor.getColumnIndexOrThrow("max_goal"))
                )
                goals.add(goal)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return goals
    }


    fun getAllCategories(userId: Int): List<Category> {
        val categories = mutableListOf<Category>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM categories WHERE user_id = ?", arrayOf(userId.toString()))

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("category_id"))
                val userIdFromDb = cursor.getInt(cursor.getColumnIndexOrThrow("user_id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("category_name"))
                val type = cursor.getString(cursor.getColumnIndexOrThrow("type")) // Add this column in DB schema

                categories.add(Category(id, userIdFromDb, name, type))
            } while (cursor.moveToNext())
        }

        cursor.close()
        return categories
    }
    fun setMonthlyBudgetGoal(userId: Int, month: String, min: Double, max: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", userId)
            put("month", month)
            put("min_goal", min)
            put("max_goal", max)
        }

        // Replace or insert: prevents duplicates for the same user+month
        val result = db.insertWithOnConflict("budget_goals", null, values, SQLiteDatabase.CONFLICT_REPLACE)
        return result != -1L
    }
    fun getAllBudgetGoalsForMonth(userId: Int): List<BudgetGoal> {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT month, min_goal, max_goal FROM budget_goals WHERE user_id = ? AND month LIKE ?",
            arrayOf(userId.toString())
        )

        val goals = mutableListOf<BudgetGoal>()
        while (cursor.moveToNext()) {
            val goal = BudgetGoal(
                month = cursor.getString(cursor.getColumnIndexOrThrow("month")),
                minGoal = cursor.getDouble(cursor.getColumnIndexOrThrow("min_goal")),
                maxGoal = cursor.getDouble(cursor.getColumnIndexOrThrow("max_goal"))
            )
            goals.add(goal)
        }
        cursor.close()
        return goals
    }


}
